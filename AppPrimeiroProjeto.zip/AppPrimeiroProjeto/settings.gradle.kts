
rootProject.name = "AppPrimeiroProjeto"

