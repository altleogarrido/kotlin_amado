/**
 * Comentário com mais detalhes
 */
fun main() {
    // Meu primeiro programa

    print("1º Programa em Kotlin...")

}



